import random

#Simulating coin flip through random choice
def flip_coin():
    return random.choice(['Heads', 'Tails'])
